package controller;
//Comentei em quase todos os blocos de código para fazer a apresentação em sala. 
import javax.swing.JOptionPane;

import model.Atividade;
import model.AtividadeTableModel;
import view.JanelaAtividade;
import view.JanelaVisualizarAtividade;

public class AtividadeController {

	//model que armazena as atividades
	private AtividadeTableModel atividadeModel;
	//tela principal do sistema
	private JanelaAtividade view;
	//construtor
	public AtividadeController(AtividadeTableModel modelo, JanelaAtividade view) {

		this.atividadeModel = modelo;
		this.view = view;
		
		//define que a JTabel vai usar o AtividadeTableModel.
		this.view.getTable().setModel(modelo);
		
		//adiciona os eventos aos botões
		this.view.getBtnCadastrar().addActionListener(e -> eventoCadastrar());

		this.view.getBtnRemover().addActionListener(e -> eventoRemover());

		this.view.getBtnVisualizar().addActionListener(e -> eventoVisualizar());

	}

	//o que acontece quando o usuário clica no borão cadastrar
	private void eventoCadastrar() {

		//capta o que o usuario digitou
		String email = view.getTxtEmail().getText();
		String nome = view.getTxtNome().getText();
		String local = view.getTxtLocal().getText();
		String tempo = view.getTxtTempo().getText();
		String tipo = view.getCbTipo().getSelectedItem().toString();
		String descricao = view.getTxtDescricao().getText();
		String dataInicio = view.getTxtDataInicio().getText();
		String dataFim = view.getTxtDataFim().getText();

		//caso algum campo não seja preenchido
		if (email.isBlank() ||
			nome.isBlank() ||
			local.isBlank() ||
			tempo.isBlank() ||
			descricao.isBlank() ||
			dataInicio.isBlank() ||
			dataFim.isBlank()) {

			JOptionPane.showMessageDialog(view,
					"Preencha todos os campos.");
			//sem esse return ele mostra a mensagem de "Atividade Cadastrada"
			return;
		}
		//cria o objeto atividade
		Atividade atividade = new Atividade(
				email,
				nome,
				local,
				tempo,
				tipo,
				descricao,
				dataInicio,
				dataFim);
		
		//adiciona a atividade no model 
		atividadeModel.adicionarAtividade(atividade);

		//limpa os campos
		view.getTxtEmail().setText("");
		view.getTxtNome().setText("");
		view.getTxtLocal().setText("");
		view.getTxtTempo().setText("");
		view.getTxtDescricao().setText("");
		view.getTxtDataInicio().setText("");
		view.getTxtDataFim().setText("");
		view.getCbTipo().setSelectedIndex(0);

		JOptionPane.showMessageDialog(view,
				"Atividade cadastrada com sucesso!");

	}

	//quando o usuário clica para remover uma linha da tabela
	private void eventoRemover() {
		//verifica qual linha foi selecionada
		int linhaSelecionada = view.getTable().getSelectedRow();

		//se o usuário não selecionou uma linha
		if (linhaSelecionada == -1) {
			JOptionPane.showMessageDialog(view,
					"Selecione uma atividade.");

			return;
		}

		//remove a linha
		atividadeModel.remover(linhaSelecionada);

	}

	//visualizar e editar uma atividade
	private void eventoVisualizar() {

		//verifica qual linha foi selecionada 
		int linhaSelecionada = view.getTable().getSelectedRow();
		
		//se o usuário não selecionou uma linha
		if (linhaSelecionada == -1) {

			JOptionPane.showMessageDialog(view,
					"Selecione uma atividade.");

			return;
		}
		//obtem a atividade selecionada
		Atividade atividade = atividadeModel.getAtividade(linhaSelecionada);

		//cria a tela de edição
		JanelaVisualizarAtividade tela = new JanelaVisualizarAtividade();
		//preenche os campus da janela com os campus da atividade selecionada
		tela.getTxtEmail().setText(atividade.getEmailMinistrante());
		tela.getTxtNome().setText(atividade.getNome());
		tela.getTxtLocal().setText(atividade.getLocal());
		tela.getTxtTempo().setText(atividade.getTempoDuracao());
		tela.getCbTipo().setSelectedItem(atividade.getTipo());
		tela.getTxtDescricao().setText(atividade.getDescricao());
		tela.getTxtDataInicio().setText(atividade.getDataInicio());
		tela.getTxtDataFim().setText(atividade.getDataFim());
		
		//botão salvar
		tela.getBtnSalvar().addActionListener(e -> {
			//le todos os campus 
			String email = tela.getTxtEmail().getText();
			String nome = tela.getTxtNome().getText();
			String local = tela.getTxtLocal().getText();
			String tempo = tela.getTxtTempo().getText();
			String tipo = tela.getCbTipo().getSelectedItem().toString();
			String descricao = tela.getTxtDescricao().getText();
			String dataInicio = tela.getTxtDataInicio().getText();
			String dataFim = tela.getTxtDataFim().getText();
			//se o usuario nao preencheu todos os campus
			if (email.isBlank() ||
				nome.isBlank() ||
				local.isBlank() ||
				tempo.isBlank() ||
				descricao.isBlank() ||
				dataInicio.isBlank() ||
				dataFim.isBlank()) {

				JOptionPane.showMessageDialog(tela,
						"Preencha todos os campos.");

				return;
			}
			//cria um novo objeto com os dados atualizados
			Atividade novaAtividade = new Atividade(
					email,
					nome,
					local,
					tempo,
					tipo,
					descricao,
					dataInicio,
					dataFim);
			
			//atualiza a atividade na lista
			atividadeModel.atualizarAtividade(
					linhaSelecionada,
					novaAtividade);

			JOptionPane.showMessageDialog(view,
					"Atividade atualizada com sucesso!");
			//fecha a tela de edição
			tela.dispose();

		});

		tela.getBtnCancelar().addActionListener(e -> {

			tela.dispose();

		});
		//centraliza a janela
		tela.setLocationRelativeTo(view);

		tela.setVisible(true);

	}

}