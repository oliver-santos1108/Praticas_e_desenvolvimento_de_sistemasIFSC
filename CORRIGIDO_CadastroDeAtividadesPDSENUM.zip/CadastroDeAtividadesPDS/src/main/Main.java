package main;
//Comentei em quase todos os blocos de código para fazer a apresentação em sala. 
import controller.AtividadeController;
import model.AtividadeTableModel;
import view.JanelaAtividade;

public class Main {

	public static void main(String[] args) {

		/*cria o model que vai armazenar as atividades
		  e fornecer os dados para a tabela.*/
		AtividadeTableModel model = new AtividadeTableModel();
		//cria a tela principal
		JanelaAtividade view = new JanelaAtividade(); 
		//cria o controller
		new AtividadeController(model, view);
		
		//view.setLocationRelativeTo(null);
		
		// deixa a janela visivel
		view.setVisible(true);

	}

}