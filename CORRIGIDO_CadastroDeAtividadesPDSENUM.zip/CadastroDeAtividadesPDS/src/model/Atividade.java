
package model;
//Comentei em quase todos os blocos de código para fazer a apresentação em sala. 

//armazena todas as informações referentes a uma atividade cadastrada.
public class Atividade {

	private String emailMinistrante;
	private String nome;
	private String local;
	private String tempoDuracao;
	private String tipo;
	private String descricao;
	private String dataInicio;
	private String dataFim;

	// construtor
	public Atividade(String emailMinistrante, String nome, String local,
			String tempoDuracao, String tipo, String descricao,
			String dataInicio, String dataFim) {

		this.emailMinistrante = emailMinistrante;
		this.nome = nome;
		this.local = local;
		this.tempoDuracao = tempoDuracao;
		this.tipo = tipo;
		this.descricao = descricao;
		this.dataInicio = dataInicio;
		this.dataFim = dataFim;
	}

	public String getEmailMinistrante() {
		return emailMinistrante;
	}

	public void setEmailMinistrante(String emailMinistrante) {
		this.emailMinistrante = emailMinistrante;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getTempoDuracao() {
		return tempoDuracao;
	}
	public void setTempoDuracao(String tempoDuracao) {
		this.tempoDuracao = tempoDuracao;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio;
	}

	public String getDataFim() {
		return dataFim;
	}

	public void setDataFim(String dataFim) {
		this.dataFim = dataFim;
	}

	
}