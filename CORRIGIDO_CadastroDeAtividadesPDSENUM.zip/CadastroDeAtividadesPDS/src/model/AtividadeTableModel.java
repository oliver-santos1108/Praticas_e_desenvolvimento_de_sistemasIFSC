package model;
//Comentei em quase todos os blocos de código para fazer a apresentação em sala. 

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

//faz a ligação entre a lista de atividades e a tabela da interface.
public class AtividadeTableModel extends AbstractTableModel {

	//lista de todas as atividades
	private ArrayList<Atividade> lista;
	
	//vetor das colunas das tabelas
	private String colunas[] = {
			"Email Ministrante",
			"Nome",
			"Local",
			"Duração",
			"Tipo",
			"Descrição",
			"Data Início",
			"Data Fim"
	};
	
	//construtor para iniciar com a lista vazia
	public AtividadeTableModel() {
		this.lista = new ArrayList<>();
	}

	//construtor que recebe a lista preenchida
	public AtividadeTableModel(ArrayList<Atividade> lista) {
		this.lista = lista;
	}

	//rotorna o nome das colunas
	@Override
	public String getColumnName(int indice) {
		return colunas[indice];
	}

	//retorna a quantidade de linhas da tabela
	@Override
	public int getRowCount() {
		return lista.size();
	}
	
	//retorna a quantidade de colunas da tabela
	@Override
	public int getColumnCount() {
		return colunas.length;
	}
	
	//retorna o valor que será exibido em cada célula da tabela.
	
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {

		Atividade atividade = lista.get(rowIndex);
		
		//verifica qual coluna está sendo acessada e retorna o atributo correspondente da atividade.
		switch (columnIndex) {

		case 0:
			return atividade.getEmailMinistrante();

		case 1:
			return atividade.getNome();

		case 2:
			return atividade.getLocal();

		case 3:
			return atividade.getTempoDuracao();

		case 4:
			return atividade.getTipo();

		case 5:
			return atividade.getDescricao();

		case 6:
			return atividade.getDataInicio();

		case 7:
			return atividade.getDataFim();

		default:
			return null;
		}

	}

	//adicina uma  atividade e atualiza a tabela
	public void adicionarAtividade(Atividade atividade) {

		lista.add(atividade);

		fireTableDataChanged();

	}

	//remove uma atividade e atualiza a tabela
	public void remover(int linhaSelecionada) {

		lista.remove(linhaSelecionada);
		fireTableDataChanged();

	}
	
	//retorna uma atividade específica da lista.
	//utilizado pelo Controller para visualizar ou editar uma atividade.
	public Atividade getAtividade(int linha) {

		return lista.get(linha);
	}

	//atualiza uma atividade que já está na lista e atualiza a tabela
	public void atualizarAtividade(int linha, Atividade atividade) {

		lista.set(linha, atividade);
		fireTableRowsUpdated(linha, linha);

	}

}