package view;
//Comentei em quase todos os blocos de código para fazer a apresentação em sala. 
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import aula6e7_JComboBox.TipoPlano;

//tela principal
public class JanelaAtividade extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
//textos
	private RoundedJTextField txtEmail;
	private RoundedJTextField txtNome;
	private RoundedJTextField txtLocal;
	private RoundedJTextField txtTempo;
	private RoundedJTextField txtDataInicio;
	private RoundedJTextField txtDataFim;
	
	
	private JTextArea txtDescricao;
//combo box tipo
	private JComboBox<TipoAtividade> cbTipo;
//botoes
	private JButton btnCadastrar;
	private JButton btnVisualizar;
	private JButton btnRemover;
//tabela
	private JTable table;
//construtor da janela
	public JanelaAtividade() {

		setTitle("Cadastro de Atividades");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 760);
		setLocationRelativeTo(null);

		contentPane = new JPanel(new BorderLayout());
		contentPane.setBackground(new Color(245,245,245));
		contentPane.setBorder(new EmptyBorder(20,20,20,20));
		setContentPane(contentPane);

		JPanel painelFormulario = new JPanel(new GridBagLayout());
		painelFormulario.setBackground(new Color(245,245,245));
		
		//posiciona os componentes
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(5,5,5,5);
		//faz os componentes crescerem horizontalmente.
		gbc.fill = GridBagConstraints.HORIZONTAL;

		JLabel titulo = new JLabel("Cadastrar Atividade");
		titulo.setFont(new Font("Tahoma", Font.BOLD, 26));
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 4;

		painelFormulario.add(titulo, gbc);
		gbc.gridwidth = 1;
		gbc.gridy++;

		painelFormulario.add(new JLabel("Email do Ministrante"), gbc);
		gbc.gridx = 2;

		painelFormulario.add(new JLabel("Nome da Atividade"), gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		txtEmail = new RoundedJTextField(20);
		txtEmail.setPreferredSize(new Dimension(250,35));

		painelFormulario.add(txtEmail, gbc);
		gbc.gridx = 2;

		txtNome = new RoundedJTextField(20);
		txtNome.setPreferredSize(new Dimension(250,35));

		painelFormulario.add(txtNome, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		JLabel novo = new JLabel("novo ministrante");
		novo.setForeground(Color.ORANGE);
		painelFormulario.add(novo, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painelFormulario.add(new JLabel("Local"), gbc);
		gbc.gridx = 2;

		painelFormulario.add(new JLabel("Tempo de duração"), gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		txtLocal = new RoundedJTextField(20);
		painelFormulario.add(txtLocal, gbc);
		gbc.gridx = 2;

		txtTempo = new RoundedJTextField(20);
		painelFormulario.add(txtTempo, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painelFormulario.add(new JLabel("Tipo"), gbc);
		gbc.gridx = 2;

		painelFormulario.add(new JLabel("Descrição"), gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		cbTipo = new JComboBox<TipoAtividade>();
		cbTipo.addItem(TipoAtividade.CURSO);
		cbTipo.addItem(TipoAtividade.OFICINA);
		cbTipo.addItem(TipoAtividade.PALESTRA);
		cbTipo.addItem(TipoAtividade.WORKSHOP);
		cbTipo.addItem(TipoAtividade.TREINAMENTO);
		cbTipo.addItem(TipoAtividade.OUTRO);

		painelFormulario.add(cbTipo, gbc);
		gbc.gridx = 2;

		txtDescricao = new JTextArea(5,20);
		txtDescricao.setLineWrap(true);
		txtDescricao.setWrapStyleWord(true);

		JScrollPane scrollDescricao = new JScrollPane(txtDescricao);
		painelFormulario.add(scrollDescricao, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painelFormulario.add(new JLabel("Data de Início"), gbc);
		gbc.gridx = 2;

		painelFormulario.add(new JLabel("Data de Término"), gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		txtDataInicio = new RoundedJTextField(20);
		txtDataInicio.setPreferredSize(new Dimension(180,35));
		painelFormulario.add(txtDataInicio, gbc);
		gbc.gridx = 2;
		
		txtDataFim = new RoundedJTextField(20);
		txtDataFim.setPreferredSize(new Dimension(180,35));
		painelFormulario.add(txtDataFim, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		gbc.gridwidth = 4;
		gbc.anchor = GridBagConstraints.CENTER;

		btnCadastrar = new JButton("Cadastrar Atividade");
		btnCadastrar.setBackground(new Color(52,168,83));
		btnCadastrar.setForeground(Color.WHITE);
		btnCadastrar.setFocusPainted(false);

		painelFormulario.add(btnCadastrar, gbc);
		contentPane.add(painelFormulario, BorderLayout.NORTH);

		JPanel painelTabela = new JPanel(new BorderLayout());
		painelTabela.setBorder(new EmptyBorder(20,0,0,0));
		painelTabela.setBackground(new Color(245,245,245));

		JLabel lblTabela = new JLabel("Atividades Cadastradas");
		lblTabela.setFont(new Font("Tahoma", Font.BOLD, 18));

		painelTabela.add(lblTabela, BorderLayout.NORTH);

		table = new JTable();

		JScrollPane scrollTabela = new JScrollPane(table);

		scrollTabela.setPreferredSize(new Dimension(900,250));

		painelTabela.add(scrollTabela, BorderLayout.CENTER);

		JPanel painelBotoes = new JPanel();
		painelBotoes.setBackground(new Color(245,245,245));

		btnVisualizar = new JButton("Editar");

		btnRemover = new JButton("Remover");

		painelBotoes.add(btnVisualizar);
		painelBotoes.add(btnRemover);

		painelTabela.add(painelBotoes, BorderLayout.SOUTH);

		contentPane.add(painelTabela, BorderLayout.CENTER);

	}
	public RoundedJTextField getTxtEmail() {
		return txtEmail;
	}

	public RoundedJTextField getTxtNome() {
		return txtNome;
	}

	public RoundedJTextField getTxtLocal() {
		return txtLocal;
	}

	public RoundedJTextField getTxtTempo() {
		return txtTempo;
	}

	public RoundedJTextField getTxtDataInicio() {
		return txtDataInicio;
	}

	public RoundedJTextField getTxtDataFim() {
		return txtDataFim;
	}

	public JTextArea getTxtDescricao() {
		return txtDescricao;
	}

	public JComboBox<String> getCbTipo() {
		return cbTipo;
	}

	public JButton getBtnCadastrar() {
		return btnCadastrar;
	}

	public JButton getBtnVisualizar() {
		return btnVisualizar;
	}

	public JButton getBtnRemover() {
		return btnRemover;
	}

	public JTable getTable() {
		return table;
	}

	public void limparCampos() {

		txtEmail.setText("");
		txtNome.setText("");
		txtLocal.setText("");
		txtTempo.setText("");
		txtDescricao.setText("");
		txtDataInicio.setText("");
		txtDataFim.setText("");
		cbTipo.setSelectedIndex(0);

	}
}