package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class JanelaVisualizarAtividade extends JDialog {

	private static final long serialVersionUID = 1L;

	private RoundedJTextField txtEmail;
	private RoundedJTextField txtNome;
	private RoundedJTextField txtLocal;
	private RoundedJTextField txtTempo;
	private RoundedJTextField txtDataInicio;
	private RoundedJTextField txtDataFim;
	private JComboBox<TipoAtividade> cbTipo;
	
	private JTextArea txtDescricao;

	private JButton btnSalvar;
	private JButton btnCancelar;

	public JanelaVisualizarAtividade() {

		setTitle("Editar Atividade");
		setModal(true);
		setSize(750, 600);
		setLocationRelativeTo(null);

		JPanel contentPane = new JPanel(new BorderLayout());
		contentPane.setBorder(new EmptyBorder(20,20,20,20));
		contentPane.setBackground(new Color(245,245,245));

		setContentPane(contentPane);

		JPanel painel = new JPanel(new GridBagLayout());
		painel.setBackground(new Color(245,245,245));

		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(6,6,6,6);
		gbc.fill = GridBagConstraints.HORIZONTAL;

		JLabel titulo = new JLabel("Editar Atividade");
		titulo.setFont(new Font("Tahoma", Font.BOLD, 24));
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridwidth = 2;

		painel.add(titulo, gbc);
		gbc.gridwidth = 1;
		gbc.gridy++;

		painel.add(new JLabel("Email do Ministrante"), gbc);
		gbc.gridx = 1;

		txtEmail = new RoundedJTextField(20);
		txtEmail.setPreferredSize(new Dimension(300,35));
		painel.add(txtEmail, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		
		painel.add(new JLabel("Nome da Atividade"), gbc);
		gbc.gridx = 1;
		
		txtNome = new RoundedJTextField(20);
		painel.add(txtNome, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painel.add(new JLabel("Local"), gbc);
		gbc.gridx = 1;
		txtLocal = new RoundedJTextField(20);
		painel.add(txtLocal, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painel.add(new JLabel("Tempo de Duração"), gbc);
		gbc.gridx = 1;
		txtTempo = new RoundedJTextField(20);
		painel.add(txtTempo, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painel.add(new JLabel("Tipo"), gbc);
		gbc.gridx = 1;
		
		cbTipo = new JComboBox<TipoAtividade>();
		cbTipo.addItem(TipoAtividade.CURSO);
		cbTipo.addItem(TipoAtividade.OFICINA);
		cbTipo.addItem(TipoAtividade.PALESTRA);
		cbTipo.addItem(TipoAtividade.WORKSHOP);
		cbTipo.addItem(TipoAtividade.TREINAMENTO);
		cbTipo.addItem(TipoAtividade.OUTRO);

		painel.add(cbTipo, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painel.add(new JLabel("Descrição"), gbc);
		gbc.gridx = 1;
		txtDescricao = new JTextArea(5,20);
		txtDescricao.setLineWrap(true);
		txtDescricao.setWrapStyleWord(true);

		JScrollPane scroll = new JScrollPane(txtDescricao);
		painel.add(scroll, gbc);
		gbc.gridx = 0;
		gbc.gridy++;

		painel.add(new JLabel("Data de Início"), gbc);
		gbc.gridx = 1;
		txtDataInicio = new RoundedJTextField(20);
		painel.add(txtDataInicio, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		
		painel.add(new JLabel("Data de Término"), gbc);
		gbc.gridx = 1;
		txtDataFim = new RoundedJTextField(20);
		painel.add(txtDataFim, gbc);

		contentPane.add(painel, BorderLayout.CENTER);

		JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.CENTER));
		painelBotoes.setBackground(new Color(245,245,245));
		btnSalvar = new JButton("Salvar");
		btnCancelar = new JButton("Cancelar");
		painelBotoes.add(btnSalvar);
		painelBotoes.add(btnCancelar);
		contentPane.add(painelBotoes, BorderLayout.SOUTH);

	}

	public RoundedJTextField getTxtEmail() {
		return txtEmail;
	}

	public RoundedJTextField getTxtNome() {
		return txtNome;
	}

	public RoundedJTextField getTxtLocal() {
		return txtLocal;
	}

	public RoundedJTextField getTxtTempo() {
		return txtTempo;
	}

	public RoundedJTextField getTxtDataInicio() {
		return txtDataInicio;
	}

	public RoundedJTextField getTxtDataFim() {
		return txtDataFim;
	}

	public JTextArea getTxtDescricao() {
		return txtDescricao;
	}

	public JComboBox<String> getCbTipo() {
		return cbTipo;
	}

	public JButton getBtnSalvar() {
		return btnSalvar;
	}

	public JButton getBtnCancelar() {
		return btnCancelar;
	}

}