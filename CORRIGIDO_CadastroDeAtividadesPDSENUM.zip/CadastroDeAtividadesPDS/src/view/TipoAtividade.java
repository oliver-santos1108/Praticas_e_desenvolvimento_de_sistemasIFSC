package view;

public enum TipoAtividade {
	CURSO ("Curso"),
	PALESTRA("Palesta"),
	OFICINA("Oficina"),
	WORKSHOP("Workshop"),
	TREINAMENTO("Treinamento"),
	OUTRO("Outro");
	
	String tipo;
	
	private TipoAtividade (String descricao) {
		this.tipo = tipo;
	}
	
	public String toString() { 
		return tipo;
	}
}
